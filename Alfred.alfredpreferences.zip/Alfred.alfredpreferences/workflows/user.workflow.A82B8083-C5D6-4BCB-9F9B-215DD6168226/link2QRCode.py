# -*- coding:utf-8 -*-
# @Author : jun
# @Time   : 2020/5/5 19:53
import argparse
import os
import sys

from workflow import Workflow3

reload(sys)
sys.setdefaultencoding("utf-8")


def add_link(link):
    import shutil
    if os.path.exists("QRCode"):
        shutil.rmtree("QRCode")
    with open("links.txt", "a") as f:
        if f.tell():
            f.write("\n")
        f.write(link)


def run():
    if not os.path.exists("QRCode"):
        os.makedirs("QRCode")
    cmd = "/Users/jun/.pyenv/versions/learn_py3/bin/python run.py"
    os.system(cmd)
    if os.path.exists("links.txt"):
        os.remove("links.txt")
    os.system("open QRCode")


def main(wf):
    parser = argparse.ArgumentParser()
    parser.add_argument('--add')
    parser.add_argument('--run', action="store_true")
    args = parser.parse_args(wf.args)

    if args.add:
        add_link(args.add)
        return 0
    elif args.run:
        run()
        return 0

    wf.send_feedback()
    return 0


if __name__ == '__main__':
    wf = Workflow3()
    log = wf.logger
    sys.exit(wf.run(main))
