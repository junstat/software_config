import aiohttp
import asyncio
import async_timeout

headers = {
    "user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.149 Safari/537.36"
}

async def fetch(session, url):
    with async_timeout.timeout(10):
        async with session.get(url, headers=headers) as response:
            if 404 == response.status:
                return None
            elif "/api.php" in url:
                return await response.read()
            else:
                return await response.text()


async def magnet2qr_code():

    with open("links.txt") as f:
        links = f.readlines()

    async with aiohttp.ClientSession() as session:
        for num, link in enumerate(links):
            url = "http://qr.topscan.com/api.php?text={}".format(link.replace("\n", ""))
            resp = await fetch(session, url)
            with open(f"./QRCode/{num}.png", "wb") as f:
                f.write(resp)



if __name__ == '__main__':
    loop = asyncio.get_event_loop()
    loop.run_until_complete(magnet2qr_code())