#!/bin/bash

args="done 0"
for x in ${args}; do
  echo ${x}
done

#job_type=`echo ${args} | awk '{print $1}'`
#task_num=`echo ${args} | awk '{print $2}'`
#echo $job_type
#echo $task_num
