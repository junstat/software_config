# -*- coding:utf-8 -*-
# @Author : jun
# @Time   : 2020/4/19 12:52


li = [1, 2, 3]
s = [2, 1, 3]
res = []
for x in s:
    # print li[x - 1]
    res.append(li[x - 1])
del li
print res
