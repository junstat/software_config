# -*- coding:utf-8 -*-
# @Author : jun
# @Time   : 2020/4/19 19:16


class Node(object):
    """链表结点"""
